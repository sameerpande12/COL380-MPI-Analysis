gcc main_omp.c -fopenmp -o main_omp.exe
./main_omp.exe $1 $2 $3 $4